<div align="center">
    <img src="https://i.imgur.com/gZzDydY.gif"><br><br>
    
---

# FAV Verifier
</div>
A simple verification script used in the FΛV Community Discord Server | Made with discord.js

# Install
1. Get nodejs from your package manager or from https://nodejs.org/. Please note that you need node v16.6 or above.
2. Install git from your package manager or https://git-scm.com/
3. Execute command `git clone https://github.com/favianrizqulloh/FAV-verifier && cd FAV-verifier`
4. Execute command `npm i`
5. Copy the .env.example file to .env and edit the .env file according to the instructions in the file.

To start the verifier, execute command `npm start` or `node index.js`. You can also open the `easy-start.bat` file if you are on Windows 10/11.

# Join us on Discord
[Click here to get support on Discord!](https://discord.io/favcommunity)
